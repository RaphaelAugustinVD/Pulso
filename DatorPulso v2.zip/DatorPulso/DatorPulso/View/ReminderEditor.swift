import SwiftUI


struct ReminderEditorView: View {
    @EnvironmentObject var store: AppDataController
    @EnvironmentObject var reminderController: ReminderController
    @Environment(\.dismiss) private var dismiss

    let editing: HealthReminder?

    @State private var title: String
    @State private var note: String
    @State private var time: Date
    @State private var days: Set<Int>
    @State private var icon: String
    @State private var errorMessage: String?
    @State private var showDeleteConfirm = false

    init(editing: HealthReminder?, preset: ReminderPreset?) {
        self.editing = editing

        if let reminder = editing {
            _title = State(initialValue: reminder.title)
            _note = State(initialValue: reminder.note)
            _time = State(initialValue: ReminderEditorView.makeDate(hour: reminder.hour, minute: reminder.minute))
            _days = State(initialValue: Set(reminder.repeatDays))
            _icon = State(initialValue: reminder.icon)
        } else if let preset = preset {
            _title = State(initialValue: preset.title)
            _note = State(initialValue: preset.note)
            _time = State(initialValue: ReminderEditorView.makeDate(hour: preset.hour, minute: preset.minute))
            _days = State(initialValue: [])
            _icon = State(initialValue: preset.icon)
        } else {
            _title = State(initialValue: "")
            _note = State(initialValue: "")
            _time = State(initialValue: ReminderEditorView.makeDate(hour: 8, minute: 0))
            _days = State(initialValue: [])
            _icon = State(initialValue: "bell.fill")
        }
    }

    private var accent: Color {
        store.selectedTheme.accentColor
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 22) {
                    section("TASK") {
                        PulsoTextField(placeholder: "e.g. Drink water", text: $title)
                    }

                    section("NOTE (OPTIONAL)") {
                        PulsoTextField(placeholder: "Shown in the notification", text: $note)
                    }

                    section("ICON") {
                        iconPicker
                    }

                    section("TIME") {
                        DatePicker("", selection: $time, displayedComponents: .hourAndMinute)
                            .datePickerStyle(.wheel)
                            .labelsHidden()
                            .frame(maxWidth: .infinity)
                            .background(Color.pulsoCard)
                            .cornerRadius(12)
                    }

                    section("REPEAT") {
                        dayPicker
                        Text("Leave all days unselected to repeat every day.")
                            .font(.footnote)
                            .foregroundColor(.pulsoSecondaryText)
                    }

                    if let errorMessage {
                        Text(errorMessage)
                            .font(.footnote)
                            .foregroundColor(.red)
                    }

                    PrimaryButton(
                        title: editing == nil ? "Save Reminder" : "Save Changes",
                        accentColor: accent,
                        action: save
                    )

                    if editing != nil {
                        SecondaryButton(title: "Delete Reminder") {
                            showDeleteConfirm = true
                        }
                    }
                }
                .padding(20)
            }
            .background(Color.pulsoBackground.ignoresSafeArea())
            .navigationTitle(editing == nil ? "New Reminder" : "Edit Reminder")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") { dismiss() }
                        .foregroundColor(.white)
                }
            }
            .alert("Delete this reminder?", isPresented: $showDeleteConfirm) {
                Button("Cancel", role: .cancel) {}
                Button("Delete", role: .destructive) {
                    if let editing {
                        reminderController.delete(editing)
                    }
                    dismiss()
                }
            } message: {
                Text("It will stop sending notifications.")
            }
        }
    }

    // MARK: - Pieces

    private func section<Content: View>(_ label: String, @ViewBuilder content: () -> Content) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(label)
                .font(.caption)
                .foregroundColor(.pulsoSecondaryText)
            content()
        }
    }

    private var iconPicker: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 10) {
                ForEach(ReminderIcons.all, id: \.self) { name in
                    iconButton(name)
                }
            }
        }
    }

    private func iconButton(_ name: String) -> some View {
        let selected = (icon == name)
        return Button {
            icon = name
        } label: {
            Image(systemName: name)
                .font(.system(size: 18))
                .foregroundColor(selected ? .black : .white)
                .frame(width: 46, height: 46)
                .background(selected ? accent : Color.pulsoCard)
                .overlay(
                    RoundedRectangle(cornerRadius: 12)
                        .stroke(selected ? accent : Color.pulsoBorder, lineWidth: 1)
                )
                .clipShape(RoundedRectangle(cornerRadius: 12))
        }
        .buttonStyle(.plain)
    }

    private var dayPicker: some View {
        HStack(spacing: 6) {
            ForEach(1...7, id: \.self) { weekday in
                dayButton(weekday)
            }
        }
    }

    private func dayButton(_ weekday: Int) -> some View {
        let selected = days.contains(weekday)
        let letter = Calendar.current.veryShortWeekdaySymbols[weekday - 1]
        return Button {
            toggleDay(weekday)
        } label: {
            Text(letter)
                .font(.system(size: 14, weight: .semibold))
                .foregroundColor(selected ? .black : .white)
                .frame(width: 40, height: 40)
                .background(selected ? accent : Color.pulsoCard)
                .overlay(
                    Circle().stroke(selected ? accent : Color.pulsoBorder, lineWidth: 1)
                )
                .clipShape(Circle())
        }
        .buttonStyle(.plain)
    }

    // MARK: - Actions

    private func toggleDay(_ weekday: Int) {
        if days.contains(weekday) {
            days.remove(weekday)
        } else {
            days.insert(weekday)
        }
    }

    private func save() {
        let trimmed = title.trimmingCharacters(in: .whitespacesAndNewlines)
        if trimmed.isEmpty {
            errorMessage = "Please enter a task name."
            return
        }
        errorMessage = nil

        let parts = Calendar.current.dateComponents([.hour, .minute], from: time)
        let hour = parts.hour ?? 8
        let minute = parts.minute ?? 0
        let chosenDays = days.sorted()
        let cleanNote = note.trimmingCharacters(in: .whitespacesAndNewlines)
        let chosenIcon = icon

        Task {
            // First save triggers the one-time iOS permission prompt.
            await NotificationController.shared.requestAuthorizationIfNeeded()

            if let editing {
                reminderController.update(
                    editing,
                    title: trimmed,
                    note: cleanNote,
                    hour: hour,
                    minute: minute,
                    repeatDays: chosenDays,
                    icon: chosenIcon
                )
            } else {
                reminderController.add(
                    title: trimmed,
                    note: cleanNote,
                    hour: hour,
                    minute: minute,
                    repeatDays: chosenDays,
                    icon: chosenIcon
                )
            }
            dismiss()
        }
    }

    private static func makeDate(hour: Int, minute: Int) -> Date {
        Calendar.current.date(bySettingHour: hour, minute: minute, second: 0, of: Date()) ?? Date()
    }
}
