import SwiftUI

struct SymptomLoggingView: View {
    @EnvironmentObject var store: AppDataController
    @Environment(\.dismiss) private var dismiss
    @ObservedObject var draft: SymptomDraft

    let date: Date
    var onSubmit: () -> Void

    @State private var errorMessage: String?

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                header

                Text("SELECT YOUR SYMPTOMS")
                    .font(.caption)
                    .foregroundColor(.pulsoSecondaryText)

                VStack(spacing: 12) {
                    ForEach(ConditionLibrary.allSymptoms, id: \.self) { symptom in
                        symptomRow(symptom)
                    }
                }

                Text("BODY TEMPERATURE")
                    .font(.caption)
                    .foregroundColor(.pulsoSecondaryText)
                    .padding(.top, 8)

                temperatureField

                if let errorMessage {
                    Text(errorMessage)
                        .font(.footnote)
                        .foregroundColor(.red)
                }

                PrimaryButton(
                    title: "Submit Symptoms",
                    accentColor: store.selectedTheme.accentColor,
                    action: submit
                )
                .padding(.top, 8)
            }
            .padding(20)
        }
        .background(Color.pulsoBackground.ignoresSafeArea())
        .navigationBarTitleDisplayMode(.inline)
        .navigationBarBackButtonHidden(true)
        .toolbar {
            ToolbarItem(placement: .navigationBarLeading) {
                Button(action: { dismiss() }) {
                    Image(systemName: "chevron.left")
                        .foregroundColor(.white)
                }
            }
        }
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text("Symptom Logging")
                .font(.system(size: 24, weight: .bold))
                .foregroundColor(.white)
            Text(formattedDate)
                .font(.subheadline)
                .foregroundColor(.pulsoSecondaryText)
        }
    }

    private var temperatureField: some View {
        HStack {
            TextField(
                "",
                text: $draft.temperature,
                prompt: Text("e.g. 98.6").foregroundColor(.pulsoSecondaryText)
            )
            .keyboardType(.decimalPad)
            .foregroundColor(.white)

            Text("F")
                .foregroundColor(.pulsoSecondaryText)
        }
        .padding(.vertical, 14)
        .padding(.horizontal, 16)
        .background(Color.pulsoCard)
        .overlay(
            RoundedRectangle(cornerRadius: 12)
                .stroke(Color.pulsoBorder, lineWidth: 1)
        )
        .cornerRadius(12)
    }

    private var formattedDate: String {
        let formatter = DateFormatter()
        formatter.dateFormat = "MMMM d, yyyy"
        return formatter.string(from: date)
    }

    private func symptomRow(_ symptom: String) -> some View {
        let isSelected = draft.selectedSymptoms.contains(symptom)
        let accent = store.selectedTheme.accentColor

        return Button {
            toggle(symptom)
        } label: {
            HStack {
                Text(symptom)
                    .foregroundColor(.white)
                Spacer()
                Image(systemName: isSelected ? "checkmark.square.fill" : "square")
                    .foregroundColor(isSelected ? accent : .pulsoSecondaryText)
            }
            .padding(.vertical, 14)
            .padding(.horizontal, 16)
            .background(Color.pulsoCard)
            .overlay(
                RoundedRectangle(cornerRadius: 12)
                    .stroke(isSelected ? accent : Color.pulsoBorder, lineWidth: 1)
            )
            .cornerRadius(12)
        }
        .buttonStyle(.plain)
    }

    private func toggle(_ symptom: String) {
        if draft.selectedSymptoms.contains(symptom) {
            draft.selectedSymptoms.remove(symptom)
        } else {
            draft.selectedSymptoms.insert(symptom)
        }
    }

    private func submit() {
        if draft.selectedSymptoms.isEmpty {
            errorMessage = "Please select at least one symptom."
            return
        }
        guard let value = draft.temperatureValue, value >= 90, value <= 110 else {
            errorMessage = "Please enter a valid body temperature (90-110 F)."
            return
        }
        errorMessage = nil
        onSubmit()
    }
}
