import SwiftUI

struct LoginView: View {
    @EnvironmentObject var store: AppDataController
    var onRegisterTap: () -> Void

    @State private var email = ""
    @State private var password = ""
    @State private var errorMessage: String?

    var body: some View {
        ScrollView {
            VStack(spacing: 24) {
                VStack(spacing: 12) {
                    RoundedRectangle(cornerRadius: 22)
                        .fill(Color.pulsoCard)
                        .frame(width: 84, height: 84)
                        .overlay(
                            Image(systemName: "heart.text.square.fill")
                                .font(.system(size: 36))
                                .foregroundColor(store.selectedTheme.accentColor)
                        )
                    Text("Pulso")
                        .font(.system(size: 30, weight: .bold))
                        .foregroundColor(.white)
                    Text("Symptom tracker & relief guide")
                        .font(.subheadline)
                        .foregroundColor(.pulsoSecondaryText)
                }
                .padding(.top, 60)

                VStack(alignment: .leading, spacing: 16) {
                    VStack(alignment: .leading, spacing: 6) {
                        FieldLabel(text: "Email Address")
                        PulsoTextField(placeholder: "sample@email.com", text: $email, keyboardType: .emailAddress)
                    }
                    VStack(alignment: .leading, spacing: 6) {
                        FieldLabel(text: "Password")
                        PulsoTextField(placeholder: "********", text: $password, isSecure: true)
                    }

                    if let errorMessage {
                        Text(errorMessage)
                            .font(.footnote)
                            .foregroundColor(.red)
                    }

                    PrimaryButton(title: "Log In", accentColor: store.selectedTheme.accentColor, action: attemptLogin)
                        .padding(.top, 8)

                    Text("or")
                        .font(.footnote)
                        .foregroundColor(.pulsoSecondaryText)
                        .frame(maxWidth: .infinity, alignment: .center)

                    SecondaryButton(title: "Register", action: onRegisterTap)
                }
                .padding(.horizontal, 28)

                Spacer(minLength: 40)
            }
        }
        .background(Color.pulsoBackground.ignoresSafeArea())
        .navigationBarHidden(true)
    }

    private func attemptLogin() {
        guard !email.trimmingCharacters(in: .whitespaces).isEmpty, !password.isEmpty else {
            errorMessage = "Please enter your email and password."
            return
        }
        guard store.attemptLogin(email: email, password: password) else {
            errorMessage = store.fullName.isEmpty
                ? "No account found. Please register first."
                : "Incorrect email or password."
            return
        }
        errorMessage = nil

    }
}
