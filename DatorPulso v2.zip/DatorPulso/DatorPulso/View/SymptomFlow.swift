import SwiftUI

struct SymptomFlowView: View {
    let date: Date
    var onFinish: () -> Void


    @StateObject private var draft = SymptomDraft()
    @State private var showMatch = false

    var body: some View {
        NavigationStack {
            SymptomLoggingView(
                draft: draft,
                date: date,
                onSubmit: { showMatch = true }
            )
            .navigationDestination(isPresented: $showMatch) {
                PossibleMatchView(
                    draft: draft,
                    date: date,
                    onFinish: onFinish
                )
            }
        }
    }
}
