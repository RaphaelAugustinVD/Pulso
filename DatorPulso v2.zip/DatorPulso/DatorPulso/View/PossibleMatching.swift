import SwiftUI

struct PossibleMatchView: View {
    @EnvironmentObject var store: AppDataController
    @Environment(\.dismiss) private var dismiss
    @ObservedObject var draft: SymptomDraft

    let date: Date
    var onFinish: () -> Void

    // Which card the user tapped (by condition name). nil = use the top match.
    @State private var chosenName: String?

    private var temperatureF: Double {
        draft.temperatureValue ?? 98.6
    }

    // Computed straight from the shared draft every time the screen draws,
    // so it can never be out of date.
    private var matches: [MatchResult] {
        SymptomMatchController.computeMatches(
            selectedSymptoms: Array(draft.selectedSymptoms),
            temperatureF: temperatureF
        )
    }

    private var activeName: String? {
        chosenName ?? matches.first?.id
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                Text("Possible Match")
                    .font(.system(size: 24, weight: .bold))
                    .foregroundColor(.white)

                if matches.isEmpty {
                    emptyNotice
                } else {
                    VStack(spacing: 14) {
                        ForEach(matches) { match in
                            matchCard(match)
                        }
                    }
                }

                disclaimer

                PrimaryButton(
                    title: "Acknowledge & Save",
                    isEnabled: !matches.isEmpty,
                    accentColor: store.selectedTheme.accentColor,
                    action: acknowledgeAndSave
                )
                .padding(.top, 4)
            }
            .padding(20)
        }
        .background(Color.pulsoBackground.ignoresSafeArea())
        .navigationBarTitleDisplayMode(.inline)
        .navigationBarBackButtonHidden(true)
        .toolbar {
            ToolbarItem(placement: .navigationBarLeading) {
                Button(action: { dismiss() }) {
                    Image(systemName: "chevron.left")
                        .foregroundColor(.white)
                }
            }
        }
    }

    private var emptyNotice: some View {
        Text("No symptoms were received. Go back and select at least one symptom.")
            .font(.footnote)
            .foregroundColor(.pulsoSecondaryText)
            .padding(16)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Color.pulsoCard)
            .cornerRadius(14)
    }

    private var disclaimer: some View {
        HStack(alignment: .top, spacing: 10) {
            Image(systemName: "info.circle")
                .foregroundColor(.pulsoSecondaryText)
            Text("This is not a substitute for professional medical advice. If symptoms worsen, consult a doctor immediately.")
                .font(.footnote)
                .foregroundColor(.pulsoSecondaryText)
        }
        .padding(14)
        .background(Color.pulsoCard)
        .cornerRadius(12)
    }

    private func matchCard(_ match: MatchResult) -> some View {
        let isSelected = (activeName == match.id)
        let accent = store.selectedTheme.accentColor

        return Button {
            chosenName = match.id
        } label: {
            VStack(alignment: .leading, spacing: 10) {
                HStack(spacing: 12) {
                    Image(systemName: match.condition.icon)
                        .foregroundColor(isSelected ? .black : accent)
                        .frame(width: 32, height: 32)
                        .background(isSelected ? accent : Color.pulsoBackground)
                        .clipShape(RoundedRectangle(cornerRadius: 8))

                    VStack(alignment: .leading, spacing: 2) {
                        Text(match.condition.name)
                            .font(.system(size: 16, weight: .semibold))
                            .foregroundColor(.white)
                        Text(match.descriptionText)
                            .font(.footnote)
                            .foregroundColor(.pulsoSecondaryText)
                    }
                    Spacer()
                    if isSelected {
                        Image(systemName: "checkmark.circle.fill")
                            .foregroundColor(accent)
                    }
                }

                if isSelected {
                    details(for: match)
                }
            }
            .padding(16)
            .background(Color.pulsoCard)
            .overlay(
                RoundedRectangle(cornerRadius: 14)
                    .stroke(isSelected ? accent : Color.pulsoBorder, lineWidth: isSelected ? 2 : 1)
            )
            .cornerRadius(14)
        }
        .buttonStyle(.plain)
    }

    private func details(for match: MatchResult) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Text("SUGGESTED REMEDIES")
                .font(.caption2)
                .foregroundColor(.pulsoSecondaryText)
            Text(match.condition.remedy)
                .font(.footnote)
                .foregroundColor(.white.opacity(0.85))
            Text("SELF-CARE & PRECAUTIONS")
                .font(.caption2)
                .foregroundColor(.pulsoSecondaryText)
                .padding(.top, 4)
            Text(match.condition.selfCare)
                .font(.footnote)
                .foregroundColor(.white.opacity(0.85))
        }
    }

    private func acknowledgeAndSave() {
        guard let name = activeName,
              let match = matches.first(where: { $0.id == name }) else {
            return
        }
        let entry = SymptomEntry(
            date: date,
            symptoms: draft.selectedSymptoms.sorted(),
            temperatureF: temperatureF,
            conditionName: match.condition.name,
            remedy: match.condition.remedy,
            matchLabel: match.matchLabel
        )
        store.addRecord(entry)
        onFinish()
    }
}
