import SwiftUI
import UserNotifications

struct EditorTarget: Identifiable {
    let id = UUID()
    let reminder: HealthReminder?
    let preset: ReminderPreset?
}

struct RemindersView: View {
    @EnvironmentObject var store: AppDataController
    @EnvironmentObject var reminderController: ReminderController
    @Environment(\.scenePhase) private var scenePhase

    var onProfileTap: () -> Void

    private enum DeleteRequest {
        case one(HealthReminder)
        case all
    }

    @State private var editorTarget: EditorTarget?
    @State private var authStatus: UNAuthorizationStatus = .notDetermined
    @State private var testMessage: String?

    @State private var isEditing = false
    @State private var deleteRequest: DeleteRequest?
    @State private var showDeleteAlert = false

    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                DashboardTopBar(
                    title: "Reminders",
                    subtitle: "Build healthy daily habits",
                    onProfileTap: onProfileTap
                )

                VStack(alignment: .leading, spacing: 20) {
                    permissionBanner
                    quickAddSection
                    addButton
                    listSection
                    testSection
                }
                .padding(.horizontal, 20)

                Spacer(minLength: 40)
            }
        }
        .background(Color.pulsoBackground.ignoresSafeArea())
        .sheet(item: $editorTarget) { target in
            ReminderEditorView(editing: target.reminder, preset: target.preset)
        }
        .alert(alertTitle, isPresented: $showDeleteAlert, presenting: deleteRequest) { request in
            Button("Cancel", role: .cancel) {}
            Button("Delete", role: .destructive) {
                perform(request)
            }
        } message: { request in
            Text(alertMessage(for: request))
        }
        .task {
            await refreshStatus()
        }
        .onChange(of: scenePhase) { _, phase in
            if phase == .active {
                Task { await refreshStatus() }
            }
        }
        .onChange(of: reminderController.reminders.count) { _, count in
            if count == 0 {
                isEditing = false
            }
        }
    }

    // MARK: - Delete alert text + action

    private var alertTitle: String {
        if case .all? = deleteRequest {
            return "Delete all reminders?"
        }
        return "Delete this reminder?"
    }

    private func alertMessage(for request: DeleteRequest) -> String {
        switch request {
        case .one(let reminder):
            return "\"\(reminder.title)\" will be removed and stop sending notifications."
        case .all:
            return "All \(reminderController.reminders.count) reminders will be removed and stop sending notifications."
        }
    }

    private func perform(_ request: DeleteRequest) {
        switch request {
        case .one(let reminder):
            reminderController.delete(reminder)
        case .all:
            reminderController.deleteAll()
        }
    }

    // MARK: - Permission banner

    @ViewBuilder
    private var permissionBanner: some View {
        switch authStatus {
        case .notDetermined:
            banner(
                text: "Allow notifications so your reminders can alert you.",
                buttonTitle: "Allow"
            ) {
                Task {
                    await NotificationController.shared.requestAuthorizationIfNeeded()
                    await refreshStatus()
                }
            }
        case .denied:
            banner(
                text: "Notifications are off for Pulso. Turn them on in Settings to get reminded.",
                buttonTitle: "Open Settings"
            ) {
                openSettings()
            }
        default:
            EmptyView()
        }
    }

    private func banner(text: String, buttonTitle: String, action: @escaping () -> Void) -> some View {
        let accent = store.selectedTheme.accentColor
        return VStack(alignment: .leading, spacing: 12) {
            HStack(alignment: .top, spacing: 10) {
                Image(systemName: "bell.badge")
                    .foregroundColor(accent)
                Text(text)
                    .font(.footnote)
                    .foregroundColor(.white.opacity(0.85))
            }
            Button(action: action) {
                Text(buttonTitle)
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundColor(.black)
                    .padding(.vertical, 8)
                    .padding(.horizontal, 16)
                    .background(accent)
                    .clipShape(Capsule())
            }
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.pulsoCard)
        .overlay(
            RoundedRectangle(cornerRadius: 14)
                .stroke(accent.opacity(0.6), lineWidth: 1)
        )
        .cornerRadius(14)
    }

    // MARK: - Quick add + add button

    private var quickAddSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("QUICK ADD")
                .font(.caption)
                .foregroundColor(.pulsoSecondaryText)

            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 10) {
                    ForEach(ReminderPreset.all) { preset in
                        presetChip(preset)
                    }
                }
            }
        }
    }

    private func presetChip(_ preset: ReminderPreset) -> some View {
        Button {
            editorTarget = EditorTarget(reminder: nil, preset: preset)
        } label: {
            HStack(spacing: 8) {
                Image(systemName: preset.icon)
                Text(preset.title)
            }
            .font(.system(size: 14, weight: .medium))
            .foregroundColor(.white)
            .padding(.vertical, 10)
            .padding(.horizontal, 14)
            .background(Color.pulsoCard)
            .overlay(
                Capsule().stroke(Color.pulsoBorder, lineWidth: 1)
            )
            .clipShape(Capsule())
        }
        .buttonStyle(.plain)
    }

    private var addButton: some View {
        PrimaryButton(
            title: "Add Custom Reminder",
            accentColor: store.selectedTheme.accentColor
        ) {
            editorTarget = EditorTarget(reminder: nil, preset: nil)
        }
    }

    // MARK: - List

    private var listSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text("YOUR REMINDERS")
                    .font(.caption)
                    .foregroundColor(.pulsoSecondaryText)
                Spacer()
                if !reminderController.reminders.isEmpty {
                    Button(isEditing ? "Done" : "Edit") {
                        withAnimation { isEditing.toggle() }
                    }
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundColor(store.selectedTheme.accentColor)
                }
            }

            if reminderController.reminders.isEmpty {
                emptyState
            } else {
                VStack(spacing: 12) {
                    ForEach(reminderController.reminders) { reminder in
                        reminderCard(reminder)
                    }
                }

                if isEditing {
                    deleteAllButton
                }
            }
        }
    }

    private var deleteAllButton: some View {
        Button {
            deleteRequest = .all
            showDeleteAlert = true
        } label: {
            Text("Delete All Reminders")
                .font(.system(size: 17, weight: .semibold))
                .foregroundColor(.red)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 16)
                .background(Color.pulsoCard)
                .overlay(
                    RoundedRectangle(cornerRadius: 14)
                        .stroke(Color.red.opacity(0.6), lineWidth: 1)
                )
                .cornerRadius(14)
        }
    }

    private var emptyState: some View {
        VStack(spacing: 10) {
            Image(systemName: "bell.slash")
                .font(.system(size: 34))
                .foregroundColor(.pulsoSecondaryText)
            Text("No reminders yet")
                .font(.system(size: 16, weight: .semibold))
                .foregroundColor(.white)
            Text("Tap a quick-add chip above, or create your own task.")
                .font(.footnote)
                .foregroundColor(.pulsoSecondaryText)
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 30)
        .background(Color.pulsoCard)
        .cornerRadius(14)
    }

    private func reminderCard(_ reminder: HealthReminder) -> some View {
        let accent = store.selectedTheme.accentColor
        let enabledBinding = Binding<Bool>(
            get: { reminder.isEnabled },
            set: { reminderController.setEnabled(reminder, $0) }
        )

        return HStack(spacing: 14) {
            Button {
                editorTarget = EditorTarget(reminder: reminder, preset: nil)
            } label: {
                HStack(spacing: 14) {
                    Image(systemName: reminder.icon)
                        .foregroundColor(reminder.isEnabled ? .black : .pulsoSecondaryText)
                        .frame(width: 40, height: 40)
                        .background(reminder.isEnabled ? accent : Color.pulsoBackground)
                        .clipShape(RoundedRectangle(cornerRadius: 10))

                    VStack(alignment: .leading, spacing: 3) {
                        Text(reminder.title)
                            .font(.system(size: 16, weight: .semibold))
                            .foregroundColor(.white)
                        Text("\(reminder.timeText) - \(reminder.repeatText)")
                            .font(.footnote)
                            .foregroundColor(.pulsoSecondaryText)
                    }
                    Spacer()
                }
            }
            .buttonStyle(.plain)

            if isEditing {
                Button {
                    deleteRequest = .one(reminder)
                    showDeleteAlert = true
                } label: {
                    Image(systemName: "trash")
                        .font(.system(size: 14, weight: .semibold))
                        .foregroundColor(.red)
                        .frame(width: 32, height: 32)
                        .background(Color.red.opacity(0.15))
                        .clipShape(Circle())
                }
                .buttonStyle(.plain)
            } else {
                Toggle("", isOn: enabledBinding)
                    .labelsHidden()
                    .tint(accent)
            }
        }
        .padding(14)
        .background(Color.pulsoCard)
        .overlay(
            RoundedRectangle(cornerRadius: 14)
                .stroke(Color.pulsoBorder, lineWidth: 1)
        )
        .cornerRadius(14)
    }

    // MARK: - Test notification

    private var testSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            SecondaryButton(title: "Send Test Notification") {
                Task {
                    let allowed = await NotificationController.shared.requestAuthorizationIfNeeded()
                    if allowed {
                        NotificationController.shared.sendTest()
                        testMessage = "Test sent. It will appear in about 5 seconds."
                    } else {
                        testMessage = "Notifications are not allowed. Enable them in Settings."
                    }
                    await refreshStatus()
                }
            }
            if let testMessage {
                Text(testMessage)
                    .font(.footnote)
                    .foregroundColor(.pulsoSecondaryText)
            }
        }
    }

    // MARK: - Helpers

    private func refreshStatus() async {
        authStatus = await NotificationController.shared.authorizationStatus()
    }

    private func openSettings() {
        if let url = URL(string: UIApplication.openSettingsURLString) {
            UIApplication.shared.open(url)
        }
    }
}
