import SwiftUI
import MapKit
import CoreLocation

struct NearbyView: View {
    @EnvironmentObject var store: AppDataController
    @StateObject private var locationController = LocationController()
    @StateObject private var placesController = NearbyPlacesController()

    var onProfileTap: () -> Void

    private enum Filter: String, CaseIterable, Identifiable {
        case all = "All"
        case pharmacy = "Pharmacies"
        case hospital = "Hospitals"
        var id: String { rawValue }
    }

    @State private var filter: Filter = .all
    @State private var position: MapCameraPosition = .userLocation(fallback: .automatic)
    @State private var selectedID: UUID?

    var body: some View {
        VStack(spacing: 14) {
            DashboardTopBar(
                title: "Nearby Help",
                subtitle: "Pharmacies and hospitals near you",
                onProfileTap: onProfileTap
            )
            filterRow
            mapView
            statusView
            resultsList
        }
        .background(Color.pulsoBackground.ignoresSafeArea())
        .task {
            locationController.start()
        }
        .onChange(of: locationController.location) { _, newLocation in
            if let newLocation {
                runSearch(at: newLocation)
            }
        }
    }

    // MARK: - Filtering

    private var filteredPlaces: [NearbyPlace] {
        switch filter {
        case .all:
            return placesController.places
        case .pharmacy:
            return placesController.places.filter { $0.kind == .pharmacy }
        case .hospital:
            return placesController.places.filter { $0.kind == .hospital }
        }
    }

    private func color(for kind: PlaceKind) -> Color {
        switch kind {
        case .pharmacy: return .green
        case .hospital: return .red
        }
    }

    // MARK: - Filter chips + refresh

    private var filterRow: some View {
        HStack(spacing: 8) {
            ForEach(Filter.allCases) { option in
                filterChip(option)
            }
            Spacer()
            Button(action: refresh) {
                Image(systemName: "arrow.clockwise")
                    .foregroundColor(.white)
                    .frame(width: 36, height: 36)
                    .background(Color.pulsoCard)
                    .clipShape(Circle())
            }
            .buttonStyle(.plain)
        }
        .padding(.horizontal, 20)
    }

    private func filterChip(_ option: Filter) -> some View {
        let selected = (filter == option)
        let accent = store.selectedTheme.accentColor
        return Button {
            filter = option
        } label: {
            Text(option.rawValue)
                .font(.system(size: 13, weight: .semibold))
                .foregroundColor(selected ? .black : .white)
                .padding(.vertical, 8)
                .padding(.horizontal, 12)
                .background(selected ? accent : Color.pulsoCard)
                .overlay(
                    Capsule().stroke(selected ? accent : Color.pulsoBorder, lineWidth: 1)
                )
                .clipShape(Capsule())
        }
        .buttonStyle(.plain)
    }

    // MARK: - Map

    private var mapView: some View {
        Map(position: $position, selection: $selectedID) {
            UserAnnotation()
            ForEach(filteredPlaces) { place in
                Marker(place.name, systemImage: place.kind.icon, coordinate: place.coordinate)
                    .tint(color(for: place.kind))
                    .tag(place.id)
            }
        }
        .mapControls {
            MapUserLocationButton()
            MapCompass()
        }
        .frame(height: 240)
        .clipShape(RoundedRectangle(cornerRadius: 16))
        .overlay(
            RoundedRectangle(cornerRadius: 16)
                .stroke(Color.pulsoBorder, lineWidth: 1)
        )
        .padding(.horizontal, 20)
    }

    // MARK: - Status messages

    @ViewBuilder
    private var statusView: some View {
        if locationController.isUsageDescriptionMissing {
            infoCard(
                icon: "gearshape",
                text: "Setup needed: in Xcode, open the target's Info tab and add Privacy - Location When In Use Usage Description, then run the app again."
            )
        } else {
            locationStatusView
        }
    }

    @ViewBuilder
    private var locationStatusView: some View {
        switch locationController.authorizationStatus {
        case .denied, .restricted:
            infoCard(
                icon: "location.slash",
                text: "Location access is off. Turn it on in Settings to see places near you.",
                buttonTitle: "Open Settings",
                action: openSettings
            )
        case .notDetermined:
            infoCard(
                icon: "location",
                text: "Allow location access when asked, to see places near you."
            )
        default:
            if placesController.isLoading {
                progressRow("Searching nearby...")
            } else if locationController.location == nil {
                if locationController.errorMessage == nil {
                    progressRow("Finding your location...")
                } else {
                    infoCard(
                        icon: "exclamationmark.triangle",
                        text: "Could not get your location. On the Simulator, choose Features > Location.",
                        buttonTitle: "Try Again",
                        action: refresh
                    )
                }
            } else if placesController.errorMessage != nil {
                infoCard(
                    icon: "wifi.slash",
                    text: placesController.errorMessage ?? "",
                    buttonTitle: "Try Again",
                    action: refresh
                )
            } else if placesController.hasSearched && filteredPlaces.isEmpty {
                infoCard(
                    icon: "magnifyingglass",
                    text: "Nothing found within about 10 km for this filter."
                )
            }
        }
    }

    private func progressRow(_ text: String) -> some View {
        HStack(spacing: 10) {
            ProgressView()
                .tint(.white)
            Text(text)
                .font(.footnote)
                .foregroundColor(.pulsoSecondaryText)
        }
        .padding(.horizontal, 20)
    }

    private func infoCard(
        icon: String,
        text: String,
        buttonTitle: String? = nil,
        action: (() -> Void)? = nil
    ) -> some View {
        let accent = store.selectedTheme.accentColor
        return VStack(alignment: .leading, spacing: 10) {
            HStack(alignment: .top, spacing: 10) {
                Image(systemName: icon)
                    .foregroundColor(accent)
                Text(text)
                    .font(.footnote)
                    .foregroundColor(.white.opacity(0.85))
            }
            if let buttonTitle, let action {
                Button(action: action) {
                    Text(buttonTitle)
                        .font(.system(size: 14, weight: .semibold))
                        .foregroundColor(.black)
                        .padding(.vertical, 8)
                        .padding(.horizontal, 16)
                        .background(accent)
                        .clipShape(Capsule())
                }
            }
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.pulsoCard)
        .cornerRadius(14)
        .padding(.horizontal, 20)
    }

    // MARK: - Results list

    private var resultsList: some View {
        ScrollViewReader { proxy in
            ScrollView {
                LazyVStack(spacing: 12) {
                    ForEach(filteredPlaces) { place in
                        placeCard(place)
                            .id(place.id)
                    }
                    disclaimer
                }
                .padding(.horizontal, 20)
                .padding(.bottom, 20)
            }
            .onChange(of: selectedID) { _, id in
                if let id {
                    withAnimation {
                        proxy.scrollTo(id, anchor: .center)
                    }
                }
            }
        }
    }

    private var disclaimer: some View {
        Text("Results come from Apple Maps and may be incomplete. In an emergency, call your local emergency number.")
            .font(.caption)
            .foregroundColor(.pulsoSecondaryText)
            .multilineTextAlignment(.center)
            .frame(maxWidth: .infinity)
            .padding(.top, 8)
    }

    private func placeCard(_ place: NearbyPlace) -> some View {
        let isSelected = (selectedID == place.id)
        let accent = store.selectedTheme.accentColor

        return VStack(alignment: .leading, spacing: 12) {
            Button {
                focus(on: place)
            } label: {
                HStack(spacing: 12) {
                    Image(systemName: place.kind.icon)
                        .foregroundColor(.white)
                        .frame(width: 40, height: 40)
                        .background(color(for: place.kind))
                        .clipShape(RoundedRectangle(cornerRadius: 10))

                    VStack(alignment: .leading, spacing: 3) {
                        Text(place.name)
                            .font(.system(size: 16, weight: .semibold))
                            .foregroundColor(.white)
                            .multilineTextAlignment(.leading)
                        Text("\(place.kind.title) - \(place.distanceText)")
                            .font(.footnote)
                            .foregroundColor(.pulsoSecondaryText)
                        if !place.address.isEmpty {
                            Text(place.address)
                                .font(.caption)
                                .foregroundColor(.pulsoSecondaryText)
                                .multilineTextAlignment(.leading)
                        }
                    }
                    Spacer()
                }
            }
            .buttonStyle(.plain)

            HStack(spacing: 10) {
                actionButton(title: "Directions", icon: "arrow.triangle.turn.up.right.diamond.fill", filled: true) {
                    openDirections(to: place)
                }
                if let phoneURL = place.phoneURL {
                    actionButton(title: "Call", icon: "phone.fill", filled: false) {
                        UIApplication.shared.open(phoneURL)
                    }
                }
            }
        }
        .padding(14)
        .background(Color.pulsoCard)
        .overlay(
            RoundedRectangle(cornerRadius: 14)
                .stroke(isSelected ? accent : Color.pulsoBorder, lineWidth: isSelected ? 2 : 1)
        )
        .cornerRadius(14)
    }

    private func actionButton(title: String, icon: String, filled: Bool, action: @escaping () -> Void) -> some View {
        let accent = store.selectedTheme.accentColor
        return Button(action: action) {
            HStack(spacing: 6) {
                Image(systemName: icon)
                Text(title)
            }
            .font(.system(size: 13, weight: .semibold))
            .foregroundColor(filled ? .black : .white)
            .padding(.vertical, 8)
            .padding(.horizontal, 14)
            .background(filled ? accent : Color.pulsoBackground)
            .overlay(
                Capsule().stroke(filled ? accent : Color.pulsoBorder, lineWidth: 1)
            )
            .clipShape(Capsule())
        }
        .buttonStyle(.plain)
    }

    // MARK: - Actions

    private func runSearch(at location: CLLocation) {
        selectedID = nil
        position = .region(
            MKCoordinateRegion(
                center: location.coordinate,
                latitudinalMeters: 7000,
                longitudinalMeters: 7000
            )
        )
        Task {
            await placesController.search(around: location.coordinate)
        }
    }

    private func refresh() {
        locationController.refresh()
        if let current = locationController.location {
            runSearch(at: current)
        }
    }

    private func focus(on place: NearbyPlace) {
        selectedID = place.id
        withAnimation {
            position = .region(
                MKCoordinateRegion(
                    center: place.coordinate,
                    latitudinalMeters: 1500,
                    longitudinalMeters: 1500
                )
            )
        }
    }

    private func openDirections(to place: NearbyPlace) {
        place.mapItem.openInMaps(launchOptions: [
            MKLaunchOptionsDirectionsModeKey: MKLaunchOptionsDirectionsModeDriving
        ])
    }

    private func openSettings() {
        if let url = URL(string: UIApplication.openSettingsURLString) {
            UIApplication.shared.open(url)
        }
    }
}
