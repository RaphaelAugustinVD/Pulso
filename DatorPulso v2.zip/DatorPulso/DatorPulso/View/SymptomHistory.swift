import SwiftUI

struct SymptomHistoryView: View {
    @EnvironmentObject var store: AppDataController
    var onProfileTap: () -> Void

    private enum DeleteRequest {
        case one(SymptomEntry)
        case all
    }

    @State private var isEditing = false
    @State private var deleteRequest: DeleteRequest?
    @State private var showDeleteAlert = false

    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                DashboardTopBar(title: "Symptom History", onProfileTap: onProfileTap)

                if store.history.isEmpty {
                    emptyState
                } else {
                    editBar

                    VStack(spacing: 14) {
                        ForEach(store.history) { entry in
                            recordCard(entry)
                        }
                    }
                    .padding(.horizontal, 20)

                    if isEditing {
                        deleteAllButton
                    }
                }

                Spacer(minLength: 40)
            }
        }
        .background(Color.pulsoBackground.ignoresSafeArea())
        .alert(alertTitle, isPresented: $showDeleteAlert, presenting: deleteRequest) { request in
            Button("Cancel", role: .cancel) {}
            Button("Delete", role: .destructive) {
                perform(request)
            }
        } message: { request in
            Text(alertMessage(for: request))
        }
        .onChange(of: store.history.count) { _, count in
            if count == 0 {
                isEditing = false
            }
        }
    }

    // MARK: - Edit bar / delete all

    private var editBar: some View {
        HStack {
            Text("\(store.history.count) saved log\(store.history.count == 1 ? "" : "s")")
                .font(.caption)
                .foregroundColor(.pulsoSecondaryText)
            Spacer()
            Button(isEditing ? "Done" : "Edit") {
                withAnimation { isEditing.toggle() }
            }
            .font(.system(size: 15, weight: .semibold))
            .foregroundColor(store.selectedTheme.accentColor)
        }
        .padding(.horizontal, 20)
    }

    private var deleteAllButton: some View {
        Button {
            deleteRequest = .all
            showDeleteAlert = true
        } label: {
            Text("Delete All History")
                .font(.system(size: 17, weight: .semibold))
                .foregroundColor(.red)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 16)
                .background(Color.pulsoCard)
                .overlay(
                    RoundedRectangle(cornerRadius: 14)
                        .stroke(Color.red.opacity(0.6), lineWidth: 1)
                )
                .cornerRadius(14)
        }
        .padding(.horizontal, 20)
    }

    // MARK: - Alert text + action

    private var alertTitle: String {
        if case .all? = deleteRequest {
            return "Delete all history?"
        }
        return "Delete this log?"
    }

    private func alertMessage(for request: DeleteRequest) -> String {
        switch request {
        case .one(let entry):
            return "\(entry.formattedDate) - \(entry.conditionName)"
        case .all:
            return "This removes all \(store.history.count) saved logs. This cannot be undone."
        }
    }

    private func perform(_ request: DeleteRequest) {
        switch request {
        case .one(let entry):
            store.deleteRecord(entry)
        case .all:
            store.resetAllData()
        }
    }

    // MARK: - Pieces

    private var emptyState: some View {
        VStack(spacing: 12) {
            Image(systemName: "tray")
                .font(.system(size: 40))
                .foregroundColor(.pulsoSecondaryText)
            Text("No symptom records yet")
                .font(.system(size: 16, weight: .semibold))
                .foregroundColor(.white)
            Text("Log your symptoms from the Home tab to start building your history.")
                .font(.footnote)
                .foregroundColor(.pulsoSecondaryText)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 40)
        }
        .padding(.top, 60)
    }

    private func recordCard(_ entry: SymptomEntry) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 10) {
                Text(entry.formattedDate)
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundColor(.white)
                Spacer()
                Text(entry.conditionName)
                    .font(.caption)
                    .foregroundColor(.black)
                    .padding(.horizontal, 10)
                    .padding(.vertical, 4)
                    .background(store.selectedTheme.accentColor)
                    .cornerRadius(8)

                if isEditing {
                    trashButton {
                        deleteRequest = .one(entry)
                        showDeleteAlert = true
                    }
                }
            }
            Text("Symptoms: \(entry.symptoms.joined(separator: ", "))")
                .font(.footnote)
                .foregroundColor(.white.opacity(0.85))
            Text("Temperature: \(entry.formattedTemperature)")
                .font(.footnote)
                .foregroundColor(.white.opacity(0.85))
            HStack(spacing: 6) {
                Image(systemName: "bandage")
                    .font(.caption)
                    .foregroundColor(.pulsoSecondaryText)
                Text("Remedy: \(entry.remedy)")
                    .font(.footnote)
                    .foregroundColor(.pulsoSecondaryText)
            }
        }
        .padding(16)
        .background(Color.pulsoCard)
        .cornerRadius(14)
    }

    private func trashButton(action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Image(systemName: "trash")
                .font(.system(size: 14, weight: .semibold))
                .foregroundColor(.red)
                .frame(width: 32, height: 32)
                .background(Color.red.opacity(0.15))
                .clipShape(Circle())
        }
        .buttonStyle(.plain)
    }
}
