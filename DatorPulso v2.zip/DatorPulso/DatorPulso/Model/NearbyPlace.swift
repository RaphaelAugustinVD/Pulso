import Foundation
import MapKit


enum PlaceKind: String, CaseIterable, Identifiable {
    case pharmacy
    case hospital

    var id: String { rawValue }

    var title: String {
        switch self {
        case .pharmacy: return "Pharmacy"
        case .hospital: return "Hospital"
        }
    }

    var icon: String {
        switch self {
        case .pharmacy: return "pills.fill"
        case .hospital: return "cross.fill"
        }
    }
}


struct NearbyPlace: Identifiable {
    let id = UUID()
    let name: String
    let kind: PlaceKind
    let coordinate: CLLocationCoordinate2D
    let address: String
    let phone: String?
    let distanceMeters: Double
    let mapItem: MKMapItem

    init(mapItem: MKMapItem, kind: PlaceKind, origin: CLLocationCoordinate2D) {
        let placemark = mapItem.placemark
        self.mapItem = mapItem
        self.kind = kind
        self.name = mapItem.name ?? kind.title
        self.coordinate = placemark.coordinate
        self.phone = mapItem.phoneNumber

        let parts = [placemark.thoroughfare, placemark.locality]
        self.address = parts.compactMap { $0 }.joined(separator: ", ")

        let from = CLLocation(latitude: origin.latitude, longitude: origin.longitude)
        let to = CLLocation(latitude: placemark.coordinate.latitude, longitude: placemark.coordinate.longitude)
        self.distanceMeters = from.distance(from: to)
    }


    var distanceText: String {
        MKDistanceFormatter().string(fromDistance: distanceMeters)
    }

 
    var phoneURL: URL? {
        guard let phone, !phone.isEmpty else { return nil }
        let digits = phone.filter { $0.isNumber || $0 == "+" }
        return URL(string: "tel://\(digits)")
    }
}
