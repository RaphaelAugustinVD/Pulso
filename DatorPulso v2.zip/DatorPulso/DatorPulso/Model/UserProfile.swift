import Foundation
import SwiftData

@Model
final class UserProfile {
    var fullName: String
    var email: String
    var password: String
    var age: Int
    var sex: String

    init(fullName: String, email: String, password: String, age: Int, sex: String) {
        self.fullName = fullName
        self.email = email
        self.password = password
        self.age = age
        self.sex = sex
    }
}
