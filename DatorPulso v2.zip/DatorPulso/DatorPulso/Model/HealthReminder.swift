import Foundation
import SwiftData


@Model
final class HealthReminder {
    var title: String
    var note: String
    var hour: Int
    var minute: Int

    var repeatDays: [Int]
    var isEnabled: Bool
    var icon: String
    var notificationID: String
    var createdAt: Date

    init(
        title: String,
        note: String = "",
        hour: Int,
        minute: Int,
        repeatDays: [Int] = [],
        icon: String = "bell.fill",
        isEnabled: Bool = true
    ) {
        self.title = title
        self.note = note
        self.hour = hour
        self.minute = minute
        self.repeatDays = repeatDays
        self.icon = icon
        self.isEnabled = isEnabled
        self.notificationID = UUID().uuidString
        self.createdAt = Date()
    }


    var isEveryDay: Bool {
        repeatDays.isEmpty || Set(repeatDays).count == 7
    }

    var timeText: String {
        let date = Calendar.current.date(bySettingHour: hour, minute: minute, second: 0, of: Date()) ?? Date()
        return date.formatted(date: .omitted, time: .shortened)
    }

    var repeatText: String {
        if isEveryDay { return "Every day" }
        let names = Calendar.current.shortWeekdaySymbols
        let picked = repeatDays.sorted().compactMap { day -> String? in
            (1...7).contains(day) ? names[day - 1] : nil
        }
        return picked.joined(separator: ", ")
    }
}


struct ReminderPreset: Identifiable {
    let title: String
    let icon: String
    let hour: Int
    let minute: Int
    let note: String

    var id: String { title }

    static let all: [ReminderPreset] = [
        ReminderPreset(title: "Drink water", icon: "drop.fill", hour: 9, minute: 0,
                       note: "Time to drink a glass of water."),
        ReminderPreset(title: "Take pills", icon: "pills.fill", hour: 8, minute: 0,
                       note: "Time to take your medicine."),
        ReminderPreset(title: "Check temperature", icon: "thermometer.medium", hour: 20, minute: 0,
                       note: "Log your temperature in Pulso."),
        ReminderPreset(title: "Take a walk", icon: "figure.walk", hour: 17, minute: 0,
                       note: "A short walk helps you stay active."),
        ReminderPreset(title: "Go to sleep", icon: "bed.double.fill", hour: 22, minute: 0,
                       note: "Wind down and get some rest.")
    ]
}

enum ReminderIcons {
    static let all: [String] = [
        "bell.fill", "drop.fill", "pills.fill", "thermometer.medium",
        "fork.knife", "figure.walk", "bed.double.fill"
    ]
}
