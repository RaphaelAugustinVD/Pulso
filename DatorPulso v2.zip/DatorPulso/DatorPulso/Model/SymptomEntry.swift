import Foundation
import SwiftData


@Model
final class SymptomEntry {
    var date: Date
    var symptoms: [String]
    var temperatureF: Double
    var conditionName: String
    var remedy: String
    var matchLabel: String

    init(
        date: Date,
        symptoms: [String],
        temperatureF: Double,
        conditionName: String,
        remedy: String,
        matchLabel: String
    ) {
        self.date = date
        self.symptoms = symptoms
        self.temperatureF = temperatureF
        self.conditionName = conditionName
        self.remedy = remedy
        self.matchLabel = matchLabel
    }

    var formattedDate: String {
        let f = DateFormatter()
        f.dateFormat = "MMMM d, yyyy"
        return f.string(from: date)
    }

    var formattedTemperature: String {
        String(format: "%.1fF", temperatureF)
    }
}
