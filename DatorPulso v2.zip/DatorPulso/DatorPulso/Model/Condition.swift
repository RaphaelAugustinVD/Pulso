import Foundation


enum FeverAffinity {
    case common   // fever is a defining/frequent symptom (e.g. flu)
    case uncommon // fever is possible but not typical (e.g. common cold)
    case never    // fever essentially rules this condition out (e.g. allergies)
}

struct Condition: Identifiable {
    let id = UUID()
    let name: String
    let icon: String
    let associatedSymptoms: Set<String>
    let feverAffinity: FeverAffinity
    let remedy: String
    let selfCare: String
}

struct MatchResult: Identifiable {
    let condition: Condition
    let matchPercent: Int
    let sharedSymptomCount: Int


    var id: String { condition.name }

    var matchLabel: String {
        switch matchPercent {
        case 60...: return "High match"
        case 30..<60: return "Moderate match"
        default: return "Low match"
        }
    }

    var descriptionText: String {
        "\(matchLabel) based on \(sharedSymptomCount) symptom\(sharedSymptomCount == 1 ? "" : "s")"
    }
}


enum ConditionLibrary {
    static let allSymptoms: [String] = [
        "Sore Throat", "Headache", "Cough", "Fatigue",
        "Chills", "Nausea", "Runny Nose", "Body Aches"
    ]

    static let all: [Condition] = [
        Condition(
            name: "Common Cold",
            icon: "cross.case.fill",
            // Cold: sore throat & runny nose common, cough mild-moderate,
            // fatigue mild; fever/aches/headache are rare for a cold.
            associatedSymptoms: ["Sore Throat", "Cough", "Runny Nose", "Fatigue"],
            feverAffinity: .uncommon,
            remedy: "OTC decongestants, saline nasal spray, cough drops, fluids.",
            selfCare: "Rest, stay hydrated with warm water, isolate to protect others."
        ),
        Condition(
            name: "Flu",
            icon: "thermometer.medium",
            // Flu: fever/chills characteristic, body aches usual & often severe,
            // fatigue can last weeks, headache prominent, cough can be severe.
            associatedSymptoms: ["Chills", "Body Aches", "Fatigue", "Headache", "Cough"],
            feverAffinity: .common,
            remedy: "Acetaminophen or ibuprofen, fluids, plenty of rest.",
            selfCare: "Monitor your temperature closely and rest as much as possible."
        ),
        Condition(
            name: "Allergies",
            icon: "leaf.fill",
            // Allergies: runny nose very common, sneezing/cough from post-nasal
            // drip, sore throat sometimes; fever is essentially never present.
            associatedSymptoms: ["Runny Nose", "Cough", "Sore Throat"],
            feverAffinity: .never,
            remedy: "Antihistamines, saline nasal spray.",
            selfCare: "Avoid known triggers and keep windows closed when pollen is high."
        ),
        Condition(
            name: "Migraine",
            icon: "bolt.heart.fill",
            // Migraine: headache is the defining symptom, usually accompanied by
            // nausea; fatigue is common in the pre-headache (prodrome) phase.
            associatedSymptoms: ["Headache", "Nausea", "Fatigue"],
            feverAffinity: .never,
            remedy: "OTC pain relievers, caffeine in moderation, dark quiet room.",
            selfCare: "Rest in a dark, quiet room and avoid bright screens."
        ),
        Condition(
            name: "Stomach Upset",
            icon: "drop.fill",
            associatedSymptoms: ["Nausea", "Body Aches", "Fatigue"],
            feverAffinity: .uncommon,
            remedy: "Hydration, bland diet, rest.",
            selfCare: "Take small sips of water and avoid heavy or spicy foods."
        )
    ]
}
