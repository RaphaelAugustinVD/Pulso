import SwiftUI

enum AppTheme: String, CaseIterable, Identifiable, Codable {
    case green, blue, red
    var id: String { rawValue }

    var accentColor: Color {
        switch self {
        case .green: return Color(red: 0.20, green: 0.85, blue: 0.45)
        case .blue: return Color(red: 0.30, green: 0.55, blue: 0.95)
        case .red: return Color(red: 0.95, green: 0.32, blue: 0.32)
        }
    }
}
