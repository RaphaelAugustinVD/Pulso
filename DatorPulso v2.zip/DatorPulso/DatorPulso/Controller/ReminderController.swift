import SwiftUI
import SwiftData
import Combine


final class ReminderController: ObservableObject {
    @Published private(set) var reminders: [HealthReminder] = []

    private let modelContext: ModelContext
    private let notifier = NotificationController.shared

    init(modelContext: ModelContext) {
        self.modelContext = modelContext
        load()

        for reminder in reminders {
            notifier.schedule(reminder)
        }
    }

    private func load() {
        let descriptor = FetchDescriptor<HealthReminder>(
            sortBy: [SortDescriptor(\.hour), SortDescriptor(\.minute)]
        )
        reminders = (try? modelContext.fetch(descriptor)) ?? []
    }

    func add(title: String, note: String, hour: Int, minute: Int, repeatDays: [Int], icon: String) {
        let reminder = HealthReminder(
            title: title,
            note: note,
            hour: hour,
            minute: minute,
            repeatDays: repeatDays,
            icon: icon
        )
        modelContext.insert(reminder)
        try? modelContext.save()
        load()
        notifier.schedule(reminder)
    }

    func update(_ reminder: HealthReminder, title: String, note: String, hour: Int, minute: Int, repeatDays: [Int], icon: String) {
        reminder.title = title
        reminder.note = note
        reminder.hour = hour
        reminder.minute = minute
        reminder.repeatDays = repeatDays
        reminder.icon = icon
        try? modelContext.save()
        load()
        notifier.schedule(reminder)
    }

    func setEnabled(_ reminder: HealthReminder, _ enabled: Bool) {
        reminder.isEnabled = enabled
        try? modelContext.save()
        if enabled {
            notifier.schedule(reminder)
        } else {
            notifier.cancel(reminder)
        }
    }

    func delete(_ reminder: HealthReminder) {
        notifier.cancel(reminder)
  
        reminders.removeAll { $0 === reminder }
        modelContext.delete(reminder)
        try? modelContext.save()
    }


    func deleteAll() {
        let all = reminders
        reminders = []
        for reminder in all {
            notifier.cancel(reminder)
            modelContext.delete(reminder)
        }
        try? modelContext.save()
    }
}
