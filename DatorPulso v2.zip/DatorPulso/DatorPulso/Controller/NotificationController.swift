import Foundation
import UserNotifications


final class NotificationController: NSObject, UNUserNotificationCenterDelegate {
    static let shared = NotificationController()

    private let center = UNUserNotificationCenter.current()

    private override init() {
        super.init()

        center.delegate = self
    }

    // MARK: - Permission

    func authorizationStatus() async -> UNAuthorizationStatus {
        let settings = await center.notificationSettings()
        return settings.authorizationStatus
    }

    @discardableResult
    func requestAuthorizationIfNeeded() async -> Bool {
        let status = await authorizationStatus()
        switch status {
        case .notDetermined:
            let granted = try? await center.requestAuthorization(options: [.alert, .sound, .badge])
            return granted ?? false
        case .authorized, .provisional, .ephemeral:
            return true
        default:
            return false
        }
    }

    // MARK: - Scheduling


    func schedule(_ reminder: HealthReminder) {
        cancel(notificationID: reminder.notificationID)
        guard reminder.isEnabled else { return }

        let content = UNMutableNotificationContent()
        content.title = reminder.title
        content.body = reminder.note.isEmpty ? "Time for: \(reminder.title)" : reminder.note
        content.sound = .default

        if reminder.isEveryDay {
            addRequest(
                content: content,
                identifier: "\(reminder.notificationID)-daily",
                hour: reminder.hour,
                minute: reminder.minute,
                weekday: nil
            )
        } else {
            for weekday in reminder.repeatDays {
                addRequest(
                    content: content,
                    identifier: "\(reminder.notificationID)-\(weekday)",
                    hour: reminder.hour,
                    minute: reminder.minute,
                    weekday: weekday
                )
            }
        }
    }

    func cancel(_ reminder: HealthReminder) {
        cancel(notificationID: reminder.notificationID)
    }

    func cancel(notificationID: String) {
        var identifiers = ["\(notificationID)-daily"]
        identifiers += (1...7).map { "\(notificationID)-\($0)" }
        center.removePendingNotificationRequests(withIdentifiers: identifiers)
        center.removeDeliveredNotifications(withIdentifiers: identifiers)
    }


    func sendTest() {
        let content = UNMutableNotificationContent()
        content.title = "Pulso test"
        content.body = "Notifications are working."
        content.sound = .default

        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 5, repeats: false)
        let request = UNNotificationRequest(identifier: "pulso-test", content: content, trigger: trigger)
        center.add(request)
    }

    private func addRequest(content: UNNotificationContent, identifier: String, hour: Int, minute: Int, weekday: Int?) {
        var components = DateComponents()
        components.hour = hour
        components.minute = minute
        if let weekday {
            components.weekday = weekday
        }
        let trigger = UNCalendarNotificationTrigger(dateMatching: components, repeats: true)
        let request = UNNotificationRequest(identifier: identifier, content: content, trigger: trigger)
        center.add(request)
    }

    // MARK: - UNUserNotificationCenterDelegate


    nonisolated func userNotificationCenter(
        _ center: UNUserNotificationCenter,
        willPresent notification: UNNotification
    ) async -> UNNotificationPresentationOptions {
        [.banner, .list, .sound]
    }
}
