import Foundation


enum SymptomMatchController {
    private static let feverThreshold = 100.4

    static func computeMatches(selectedSymptoms: [String], temperatureF: Double) -> [MatchResult] {
        guard !selectedSymptoms.isEmpty else { return [] }
        let selected = Set(selectedSymptoms)
        let hasFever = temperatureF >= feverThreshold

        let scored: [MatchResult] = ConditionLibrary.all.compactMap { condition in
            let shared = condition.associatedSymptoms.intersection(selected)
            guard !shared.isEmpty else { return nil }

            var score = (Double(shared.count) / Double(selected.count)) * 100.0

            switch (hasFever, condition.feverAffinity) {
            case (true, .common):
                score = min(100, score + 15)
            case (true, .never):
                score = max(0, score - 20)
            case (false, .common):
                score = max(0, score - 10)     
            default:
                break
            }

            return MatchResult(
                condition: condition,
                matchPercent: Int(score.rounded()),
                sharedSymptomCount: shared.count
            )
        }
        .sorted { $0.matchPercent > $1.matchPercent }

        if scored.isEmpty {

            let fallback = ConditionLibrary.all[0]
            return [MatchResult(condition: fallback, matchPercent: 10, sharedSymptomCount: 0)]
        }
        return Array(scored.prefix(3))
    }
}
