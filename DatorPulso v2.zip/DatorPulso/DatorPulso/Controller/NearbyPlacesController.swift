import Foundation
import MapKit
import Combine


@MainActor
final class NearbyPlacesController: ObservableObject {
    @Published private(set) var places: [NearbyPlace] = []
    @Published private(set) var isLoading = false
    @Published private(set) var hasSearched = false
    @Published private(set) var errorMessage: String?

    private let resultsPerKind = 15

    private let maxDistanceMeters = 10_000.0

    private let minimumStrictResults = 5

    func search(around center: CLLocationCoordinate2D, radiusMeters: Double = 5000) async {
        isLoading = true
        errorMessage = nil
        defer {
            isLoading = false
            hasSearched = true
        }

        let region = MKCoordinateRegion(
            center: center,
            latitudinalMeters: radiusMeters * 2,
            longitudinalMeters: radiusMeters * 2
        )

        do {
            let pharmacies = try await find(
                query: "pharmacy drugstore",
                category: .pharmacy,
                kind: .pharmacy,
                region: region,
                origin: center
            )
            let hospitals = try await find(
                query: "hospital",
                category: .hospital,
                kind: .hospital,
                region: region,
                origin: center
            )
            places = (pharmacies + hospitals).sorted { $0.distanceMeters < $1.distanceMeters }
        } catch {
            errorMessage = "Could not load nearby places. Check your internet connection and try again."
        }
    }


    private func find(
        query: String,
        category: MKPointOfInterestCategory,
        kind: PlaceKind,
        region: MKCoordinateRegion,
        origin: CLLocationCoordinate2D
    ) async throws -> [NearbyPlace] {
        var combined = try await runSearch(
            query: query,
            filter: MKPointOfInterestFilter(including: [category]),
            allowed: category,
            kind: kind,
            region: region,
            origin: origin
        )

        if combined.count < minimumStrictResults {
            let loose = try await runSearch(
                query: query,
                filter: nil,
                allowed: category,
                kind: kind,
                region: region,
                origin: origin
            )
            combined += loose
        }


        var seen = Set<String>()
        var unique: [NearbyPlace] = []
        for place in combined {
            let lat = Int(place.coordinate.latitude * 10_000)
            let lon = Int(place.coordinate.longitude * 10_000)
            let key = "\(place.name)|\(lat)|\(lon)"
            if seen.insert(key).inserted {
                unique.append(place)
            }
        }

        let nearestFirst = unique.sorted { $0.distanceMeters < $1.distanceMeters }
        return Array(nearestFirst.prefix(resultsPerKind))
    }

    private func runSearch(
        query: String,
        filter: MKPointOfInterestFilter?,
        allowed: MKPointOfInterestCategory,
        kind: PlaceKind,
        region: MKCoordinateRegion,
        origin: CLLocationCoordinate2D
    ) async throws -> [NearbyPlace] {
        let request = MKLocalSearch.Request()
        request.naturalLanguageQuery = query
        request.region = region
        if let filter {
            request.pointOfInterestFilter = filter
        }

        do {
            let response = try await MKLocalSearch(request: request).start()
            return response.mapItems
                .filter { item in
                    let category = item.pointOfInterestCategory
                    return category == nil || category == allowed
                }
                .map { NearbyPlace(mapItem: $0, kind: kind, origin: origin) }
                .filter { $0.distanceMeters <= maxDistanceMeters }
        } catch let error as MKError where error.code == .placemarkNotFound {

            return []
        }
    }
}
