import Foundation
import Combine


final class SymptomDraft: ObservableObject {
    @Published var selectedSymptoms: Set<String> = []
    @Published var temperature: String = ""


    var temperatureValue: Double? {
        let cleaned = temperature
            .trimmingCharacters(in: .whitespaces)
            .replacingOccurrences(of: ",", with: ".")
        return Double(cleaned)
    }
}
