import SwiftUI
import SwiftData
import Combine


final class AppDataController: ObservableObject {
    @Published private(set) var currentUser: UserProfile?
    @Published var isLoggedIn: Bool = false
    @Published var history: [SymptomEntry] = []
    @Published var selectedTheme: AppTheme = .green
    @Published var profileImage: UIImage?

    private let modelContext: ModelContext
    private let defaults = UserDefaults.standard

    private enum Keys {
        static let theme = "pulso.theme"
        static let loggedIn = "pulso.loggedIn"
    }

    private var profileImageURL: URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("pulso_profile.jpg")
    }


    var fullName: String { currentUser?.fullName ?? "" }
    var age: String { currentUser.map { String($0.age) } ?? "" }
    var sex: String { currentUser?.sex ?? "" }

    init(modelContext: ModelContext) {
        self.modelContext = modelContext
        load()
    }

    private func load() {

        let userDescriptor = FetchDescriptor<UserProfile>()
        currentUser = (try? modelContext.fetch(userDescriptor))?.first

        let historyDescriptor = FetchDescriptor<SymptomEntry>(
            sortBy: [SortDescriptor(\.date, order: .reverse)]
        )
        history = (try? modelContext.fetch(historyDescriptor)) ?? []

        if let rawTheme = defaults.string(forKey: Keys.theme),
           let theme = AppTheme(rawValue: rawTheme) {
            selectedTheme = theme
        }
        isLoggedIn = defaults.bool(forKey: Keys.loggedIn)

        if let imageData = try? Data(contentsOf: profileImageURL),
           let image = UIImage(data: imageData) {
            profileImage = image
        }
    }



    func saveUser(_ user: UserProfile) {

        let existing = (try? modelContext.fetch(FetchDescriptor<UserProfile>())) ?? []
        for old in existing where old !== user {
            modelContext.delete(old)
        }
        modelContext.insert(user)
        try? modelContext.save()
        currentUser = user
    }

    func attemptLogin(email: String, password: String) -> Bool {
        guard let user = currentUser,
              user.email.lowercased() == email.trimmingCharacters(in: .whitespaces).lowercased(),
              user.password == password else {
            return false
        }
        login()
        return true
    }

    func login() {
        isLoggedIn = true
        defaults.set(true, forKey: Keys.loggedIn)
    }

    func logout() {
        isLoggedIn = false
        defaults.set(false, forKey: Keys.loggedIn)
    }

    // MARK: - Symptom history

    func addRecord(_ record: SymptomEntry) {
        modelContext.insert(record)
        try? modelContext.save()
        history.insert(record, at: 0)
        history.sort { $0.date > $1.date }
    }

    /// Deletes a single saved log. Removed from the on-screen list first,
    /// then from storage, so no row ever points at a deleted record.
    func deleteRecord(_ record: SymptomEntry) {
        history.removeAll { $0 === record }
        modelContext.delete(record)
        try? modelContext.save()
    }

    func hasRecord(on date: Date) -> Bool {
        let cal = Calendar.current
        return history.contains { cal.isDate($0.date, inSameDayAs: date) }
    }

    // MARK: - Theme

    func setTheme(_ theme: AppTheme) {
        selectedTheme = theme
        defaults.set(theme.rawValue, forKey: Keys.theme)
    }

    // MARK: - Profile image

    func setProfileImage(_ image: UIImage) {
        profileImage = image
        if let data = image.jpegData(compressionQuality: 0.8) {
            try? data.write(to: profileImageURL)
        }
    }

    // MARK: - Reset

    func resetAllData() {
        for entry in history {
            modelContext.delete(entry)
        }
        try? modelContext.save()
        history.removeAll()
    }
}
