import SwiftUI

struct RootView: View {
    @EnvironmentObject var store: AppDataController
    @State private var showOnboarding = true

    var body: some View {
        Group {
            if showOnboarding {
                OnboardingView {
                    withAnimation { showOnboarding = false }
                }
            } else if store.isLoggedIn {
                DashboardView(onLogout: { store.logout() })
            } else {
                AuthFlowView()
            }
        }
    }
}


struct AuthFlowView: View {
    @State private var showRegister = false

    var body: some View {
        NavigationStack {
            LoginView(onRegisterTap: { showRegister = true })
                .navigationDestination(isPresented: $showRegister) {
                    RegisterView()
                }
        }
    }
}
