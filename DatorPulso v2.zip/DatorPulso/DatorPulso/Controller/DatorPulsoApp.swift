import SwiftUI
import SwiftData

@main
struct PulsoApp: App {
    private let modelContainer: ModelContainer
    @StateObject private var store: AppDataController
    @StateObject private var reminderController: ReminderController

    init() {
        let tabAppearance = UITabBarAppearance()
        tabAppearance.configureWithOpaqueBackground()
        tabAppearance.backgroundColor = UIColor(red: 0.04, green: 0.05, blue: 0.07, alpha: 1)
        UITabBar.appearance().standardAppearance = tabAppearance
        UITabBar.appearance().scrollEdgeAppearance = tabAppearance

        let navAppearance = UINavigationBarAppearance()
        navAppearance.configureWithOpaqueBackground()
        navAppearance.backgroundColor = UIColor(red: 0.04, green: 0.05, blue: 0.07, alpha: 1)
        navAppearance.titleTextAttributes = [.foregroundColor: UIColor.white]
        navAppearance.largeTitleTextAttributes = [.foregroundColor: UIColor.white]
        UINavigationBar.appearance().standardAppearance = navAppearance
        UINavigationBar.appearance().scrollEdgeAppearance = navAppearance
        UINavigationBar.appearance().tintColor = .white

        // Create the SwiftData store for UserProfile + SymptomEntry + HealthReminder.
        let container: ModelContainer
        do {
            container = try ModelContainer(for: UserProfile.self, SymptomEntry.self, HealthReminder.self)
        } catch {
            fatalError("Could not create ModelContainer: \(error)")
        }
        self.modelContainer = container
        _store = StateObject(wrappedValue: AppDataController(modelContext: container.mainContext))
        _reminderController = StateObject(wrappedValue: ReminderController(modelContext: container.mainContext))
    }

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(store)
                .environmentObject(reminderController)
                .modelContainer(modelContainer)
                .preferredColorScheme(.dark)
        }
    }
}
